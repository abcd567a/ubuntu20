#
# Tcl package index file
#
package ifneeded Tcllauncher 1.8 \
    [list source [file join $dir tcllauncher-support.tcl]]
